Ext.define('myapp.controller.EmpController',{
	extend:'Ext.app.Controller',
	views:['EmpForm','EmpPage','EditEmp'],
	models:['EmpModel'],
	stores:['EmployeeStore'],
	refs:[
	  {ref:'empForm'},
	  {ref:'empPage'},
	  {ref:'empEdit'}
	      ],
	      
	 init:function(){
		this.control({
			'empForm button[action=create]':{
				click:this.createEmp
			},
			'empForm button[action=clear]':{
				click:this.clearEmp
			},
			'empPage':{
				itemdblclick:this.editEmp
			},
			'empEdit button[action=save]':{
				click:this.updateEmp
			},
			'empPage button[action=delete]':{
				click:this.onDelete
			}
		});
	 },
	 
	 createEmp:function(button){
		 var emp=this.getEmpForm();
		 var empObj=button.up('form[name=empForm]');
		 var empValues=empObj.getValues();
	
		 var empPage=empObj.up('container[name=viewport]');
		 var home=empPage.down('panel[name=empPage]');
		 console.log(empValues);
		 var tempId;
		 
		 //For unique id existence in store
		 var grid=Ext.getCmp('empGrid');
		 var empStore=grid.getStore('employee');
		 var empRecord=empStore.findRecord('Id',empValues.Id);
		
	if(!empRecord){
		// Verifies all the fields are filled are not
		if(!(Ext.isEmpty(empValues.Id)|| Ext.isEmpty(empValues.firstName)||
				Ext.isEmpty(empValues.lastName) || Ext.isEmpty(empValues.dob)|| Ext.isEmpty(empValues.department))){
			if((empValues.Id>=100 && empValues.Id<=999)){
				var newRecord=new myapp.model.EmpModel(empValues);
				this.getEmployeeStoreStore().add(newRecord);
				
				Ext.Msg.alert('status','Created Successfully...');
				//empObj.setVisible(false);
				home.setVisible(true);
		}
			else
				Ext.Msg.alert('status','Id should be 3 digit number');
		}
		else{
			Ext.Msg.alert('status','* Please Enter the details in fields *');
		}
		 /*Ext.each(this.getForm().getFields().items, function(field){
             field.setValue('');});*/
		
		 }
	else
		return Ext.Msg.alert('status','Id already Exists...');
		 
		
		empObj.getForm().reset();
	 },
	 
	 
	 
	 //Edit employee details
	 editEmp:function(grid,record){
		 var view=Ext.widget('empEdit');
		 view.down('form').loadRecord(record);
		// console.log('double click on '+' '+ record.get('firstName'));
	 },
	 
	 //updating employee details
	 updateEmp:function(button){
		 var win=button.up('window');
		 var form=win.down('form').getForm();
		 
		 if(form.isValid()){
			 var record=form.getRecord();
			 var values=form.getValues();
			 
			 if(!record){
				 var newRecord=new myapp.model.EmpModel(values);
				 this.getEmpStoreStore().add(newRecord);
			 }
			 else
				 record.set(values);
			 win.close();
		 }
		 
	 },
	 
	 //Delete employee record
	onDelete:function(){
		var grid=Ext.getCmp('empGrid');
		var empStore=grid.getStore('employee');

		var selectedRows=grid.getSelectionModel().getSelection();
		if(selectedRows.length)
			empStore.remove(selectedRows);
		else
			Ext.Msg.alert('status','Select atleast 1 row');
	},
	 
	 //clear form
	 clearEmp:function(button){
		 var emp=button.up('form[name=empForm]');
		 emp.getForm().reset();
	 }
});