Ext.define('myapp.model.EmpModel',{
	extend:'Ext.data.Model',
	fields:[
	   {name:'Id', type:'int'},
	   {name:'firstName', type:'string'},
	   {name:'lastName', type:'string'},
	   {name:'dob', type:'date'},
	   {name:'email', type:'string'},
	   {name:'salary', type:'double'},
	   {name:'department', type:'string'}
	        ]
});