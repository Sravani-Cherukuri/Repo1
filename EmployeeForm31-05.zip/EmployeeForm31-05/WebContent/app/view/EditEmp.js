Ext.define('myapp.view.EditEmp',{
	extend:'Ext.window.Window',
	alias:'widget.empEdit',
	title:'Edit Employee',
	name:'empEdit',
	autoShow:true,
	initComponent:function(){
		this.items=[
		   {    
		        xtype:'form',
		        items:[
		           {
		        	   xtype:'textfield',
		        	   fieldLabel:'Id',
		        	   name:'Id',
		        	   validator:function(value){
				    		 if(value>=100 && value<=999)
				    			 return true;
				    		 else
				    			 return 'Id should be 3 digit number';
				    	 }
		           },
		           {
				    	 xtype:'textfield',
				    	 fieldLabel:'Firstname',
				    	 name:'firstName',
				    	 allowBlank:false,
				    	 minLength:3,
				    	 maxLength:30
				     },
				     {
				    	 xtype:'textfield',
				    	 fieldLabel:'Lastname',
				    	 name:'lastName'
				     },
				     {
				    	 xtype:'datefield',
				    	 fieldLabel:'Date of Birth',
				    	 name:'dob'
				     },
				     {
				    	 xtype:'textfield',
				    	 fieldLabel:'Email',
				    	 name:'email',
				    	 vtype:'email'
				     },
				     {
				    	 xtype:'textfield',
				    	 fieldLabel:'Salary',
				    	 name:'salary',
				    	 validator:function(value){
				    		 if(value>=100)
				    			 return true;
				    		 else
				    			 return 'Salary shouldnot be alphanumeric value';
				    	 }
				     },
				     {
				    	 xtype:'combobox',
				    	 fieldLabel:'ChooseDepartment',
				    	 name:'department',
				    	 store:'EmpDeptStore',
				    	 displayField:'name',
				    	 valueField:'abbr',
				    	 editable:false
				     } 
		             ]
		   } ],
		   
		   this.buttons=[
		        {text:'Save',action:'save'},
		        {text:'Cancel', action:'cancel',scope:this, handler:this.close}
		                 ]
		this.callParent(arguments);
	}
});