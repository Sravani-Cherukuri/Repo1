Ext.define('myapp.view.EmpForm',{
	extend:'Ext.form.Panel',
	alias:'widget.empForm',
	name:'empForm',
	title:'Employee Form',
	stores:['EmpDeptStore','EmployeeStore'],
	reset:true,
	initComponent:function(){
		this.items=[{
		   style: 'margin:0 auto;margin-top:100px;',  
		   items:[
		     {
		    	 xtype:'textfield',
		    	 fieldLabel:'Id',
		    	 name:'Id',
		    	 allowBlank:false,
		    	 validator:function(value){
		    		 if(value>=100 && value<=999)
		    			 return true;
		    		 else
		    			 return 'Id should be 3 digit number';
		    	 }
		     },
		     {
		    	 xtype:'textfield',
		    	 fieldLabel:'Firstname',
		    	 name:'firstName',
		    	 allowBlank:false,
		    	 minLength:3,
		    	 maxLength:30
		     },
		     {
		    	 xtype:'textfield',
		    	 fieldLabel:'Lastname',
		    	 name:'lastName'
		     },
		     {
		    	 xtype:'datefield',
		    	 fieldLabel:'Date of Birth',
		    	 name:'dob'
		     },
		     {
		    	 xtype:'textfield',
		    	 fieldLabel:'Email',
		    	 name:'email',
		    	 vtype:'email'
		     },
		     {
		    	 xtype:'textfield',
		    	 fieldLabel:'Salary',
		    	 name:'salary',
		    	 validator:function(value){
		    		 if(value>=100)
		    			 return true;
		    		 else
		    			 return 'Salary shouldnot be alphanumeric value';
		    	 }
		     },
		     {
		    	 xtype:'combobox',
		    	 fieldLabel:'ChooseDepartment',
		    	 name:'department',
		    	 store:'EmpDeptStore',
		    	 displayField:'name',
		    	 valueField:'abbr',
		    	 editable:false
		     } 
		    ]
	}],
	this.buttons=[
	             {
	            	 text:'Create',
	            	 action:'create'
	             },
	             {
	            	 text:'Clear',
	            	 action:'clear'
	             }
	              ]
		this.callParent(arguments);
	},
	 clearForm:function(){
	        Ext.each(this.getForm().getFields().items, function(field){
	               field.setValue('');
	        });
	    }
});

/*Ext.override(Ext.form.Panel, {
   
});*/