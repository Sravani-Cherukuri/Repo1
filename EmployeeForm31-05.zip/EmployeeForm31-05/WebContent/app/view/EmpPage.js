Ext.define('myapp.view.EmpPage',{
	extend:'Ext.grid.Panel',
	alias:'widget.empPage',
	title:'Employee Page',
	name:'empPage',
	id:'empGrid',
	height:250,
	layout:'border',
	//style:'border-bottom-width:1px;border-bottom-color:green',
	autoScroll:true,
	selType:'checkboxmodel',
	selModel:{mode:'MULTI'},
	initComponent:function(){
		this.store='EmployeeStore',
		this.columns=[
		     {header:'Id', dataIndex:'Id',flex:1},
		     {header:'Firstname', dataIndex:'firstName',flex:1},
		     {header:'Lastname', dataIndex:'lastName',flex:1},
		     {header:'Date of Birth', dataIndex:'dob',flex:1},
		     {header:'Email', dataIndex:'email',flex:1},
		     {header:'Salary', dataIndex:'salary',flex:1},
		     {header:'Department', dataIndex:'department',flex:1}
		              ],
		 this.buttons=[{text:'Delete',action:'delete'}]         
		this.callParent(arguments);
	}
});