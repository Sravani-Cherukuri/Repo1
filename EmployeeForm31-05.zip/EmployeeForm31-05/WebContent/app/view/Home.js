Ext.define('myapp.view.Home',{
	extend:'Ext.Panel',
	alias:'widget.homePage',
	name:'homePage',
	title:'Success Page',
	renderTo:'divId',
	html:'<h1>Employee details created...</h1>'
});