package org.capgemini.test;

import static org.junit.Assert.*;

import org.capgemini.dao.ProductDao;
import org.capgemini.dto.Address;
import org.capgemini.dto.Product;
import org.capgemini.dto.Supplier;
import org.capgemini.exception.InvalidProductQuantityException;
import org.capgemini.service.ProductService;
import org.capgemini.service.ProductServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

public class MockitoTestCase {
	@Mock
	private ProductDao prdtDao;
	private ProductService prdtService;
	
	@Before
	public void beforeMethod(){
		MockitoAnnotations.initMocks(this);
		prdtService=new ProductServiceImpl(prdtDao);
	}

	@Test/*(expected=InvalidProductQuantityException.class)*/
	public void test_ProduceProduct() throws InvalidProductQuantityException{
		Product product=new Product();
		product.setProductId(203);
		product.setProductName("Monitor");
		product.setPrice(3000);
		Supplier suppli=new Supplier();
		suppli.setSupplierId(111);
		suppli.setSupplierName("Lenovo");
		suppli.setAddress(new Address());
		product.setQuantity(20);
		product.setSupplier(suppli);
		//Declaration
		Mockito.when(prdtService.findProduct(203)).thenReturn(product);
		
		//actual business logic
		Product prdt1=prdtService.produceProduct(203, 5);
		//verification
		Mockito.verify(prdtDao).findProduct(203);
		
		assertEquals(25, prdt1.getQuantity());
	}
}
