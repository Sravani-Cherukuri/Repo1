package org.capgemini.test;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collection;

import org.capgemini.service.ProductService;
import org.capgemini.service.ProductServiceImpl;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

@RunWith(Parameterized.class)
public class FindSquareParameterTestCase {

	private int inputNum;
	private int expectedResult;
	private ProductService prdtService;
	public FindSquareParameterTestCase(int inputNum, int expectedResult){
		this.inputNum=inputNum;
		this.expectedResult=expectedResult;
	}
	@Before
	public void beforeMethod(){
		prdtService=new ProductServiceImpl();
	}
	@Parameterized.Parameters
	public static Collection setOfNumbersForTest(){
		return Arrays.asList(new Object[][]{
			{2,4},{-3,9},{0,0},{4,16},{9,81}
		});
	}
	@Test
	public void test() {
		assertEquals(expectedResult,prdtService.findSquare(inputNum));
	}

}
