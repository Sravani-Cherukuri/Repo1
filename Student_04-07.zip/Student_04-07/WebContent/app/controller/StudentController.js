Ext.define('myapp.controller.StudentController',{
	extend:'Ext.app.Controller',
	stores:['StudentStore'],
	views:['StudentPage','StudentView','View','ForgotView'],
	refs:[
	      {ref:'studetnGrid'},
	      {ref:'studentPage'},
	      {ref:'loginForm'},
	      {ref:'forgotPage'}
	      ],
	      
	 init:function(){
		 this.control({
			'loginForm button[action=login]':{
				click:this.loginUser
			},
			'loginForm button[action=cancel]':{
				click:this.cancelLogin
			},
			'loginForm button[action=forgot]':{
				click:this.forgotPwd
			},
			'forgotPage button[action=cancel]':{
				click:this.onForgotCancel
			},
			'studentGrid button[action=save]':{
				 click:this.onUpdate
			 },
			'studentGrid button[action=add]':{
				click:this.onAdd
			},
			'studentGrid button[action=load]':{
				click:this.onLoad
			},
			'studentGrid button[action=delete]':{
				click:this.onDelete
			},
			'studentGrid button[action=logout]':{
				click:this.onLogout
			},
			'studentPage button[action=back]':{
				click:this.onBack
			}
			
	 });
	 },
	 
loginUser:function(btn){
	var login=btn.up('form[name=loginForm]');
	var creds=login.getValues();
	//console.log(creds.username);
	var page=login.up('container[name=viewport]');
	var grid=page.down('panel[id=studentGrid]');
	if(creds.username=='admin'&& creds.password=='password'){
		login.setVisible(false);
		grid.setVisible(true);
	}else
		Ext.Msg.alert('status','*Invalid Credentials*');
},

cancleLogin:function(btn){
	var login=btn.up('form[name=loginForm]');
	login.getForm().reset();
	Ext.Msg.alert('status','Login cancelled');
},

forgotPwd:function(button){
	var win=Ext.widget('forgotPage');
	//var form=win.down('form').getForm();
	win.show();
},

onForgotCancel:function(){
	var win=Ext.widget('forgotPage');
	//win.getForm().reset();
	win.hide();
	console.log('hidden');
},
	 
onAdd:function(btn){
	//console.log('creating...')
	var studentForm=btn.up('grid[id=studentGrid]');/*Ext.getCmp('studentGrid');*/
	//console.log(studentForm);
	var store=studentForm.getStore('student');
	
	var studentModel=Ext.create('myapp.model.StudentModel');
	studentModel.set("Id","000");
	studentModel.set("firstName","student's first name");
	studentModel.set("lastName","student's last name");
	studentModel.set("dob","11/01/1998");
	studentModel.set("city","new city");
	studentModel.set("state","new state");
	
	store.add(studentModel);
},

onUpdate:function(btn){	
	var grid=Ext.getCmp('studentGrid');
	var selectedRow=grid.getSelectionModel().getSelection();
	//console.log(selectedRow.length);
	if(selectedRow.length){
		var record=selectedRow[0];
		var storeData=this.getStudentStoreStore();
		var existedData=storeData.findRecord('Id',record.get('Id'));
		//console.log(record.get('Id'));
		//console.log("data from store is");
		//console.log(existedData);
		if(!existedData){
			this.getStudentStoreStore().add(record);
			Ext.Msg.alert('status','data saved...');
		}
		else
			Ext.Msg.alert('status','data already existed...');
		//console.log(record);
	}
},
onLoad:function(btn){
	var stdGrid=btn.up('grid[id=studentGrid]');
	var page=stdGrid.up('container[name=viewport]');
	var stdPage=page.down('panel[name=studentPage]');
	
	var grid=Ext.getCmp('studentGrid');
	var stdStore=grid.getStore('student');
	//console.log(stdStore);
	stdGrid.setVisible(false);
	stdPage.setVisible(true);
},

onDelete:function(){
	var grid=Ext.getCmp('studentGrid');
	var stdStore=grid.getStore('student');
	var selectedRows=grid.getSelectionModel().getSelection();
	if(selectedRows.length){
		stdStore.remove(selectedRows);
	}
	else
		Ext.Msg.alert('status','* Please select atleast 1 row');
},

onLogout:function(){
	var grid=Ext.getCmp('studentGrid');
	var login=Ext.getCmp('login');
	grid.setVisible(false);
	login.getForm().reset();
	login.setVisible(true);
	Ext.Msg.alert('status','You are logged out...')
},

onBack:function(btn){
	var stdPage=btn.up('grid[name=studentPage]');
	var grid=Ext.getCmp('studentGrid');
	stdPage.setVisible(false);
	grid.setVisible(true);
}

});