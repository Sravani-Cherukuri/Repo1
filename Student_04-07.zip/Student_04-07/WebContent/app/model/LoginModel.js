Ext.define('myapp.model.LoginModel',{
	extend:'Ext.data.Model',
	fields:['username','password'],
});