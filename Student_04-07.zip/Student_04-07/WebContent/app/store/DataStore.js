Ext.define('myapp.store.DataStore',{
	extend:'Ext.data.Store',
	model:'myapp.model.StudentModel',
	storeId:'data',
	data:[
	      {Id:101,firstName:'Student1', lastName:'Student1 lastName',dob:'1/01/2001',city:'city1',state:'state1'},
	      {Id:102,firstName:'Student2', lastName:'Student2 lastName',dob:'1/01/2001',city:'city2',state:'state2'},
	      {Id:103,firstName:'Student3', lastName:'Student3 lastName',dob:'1/01/2001',city:'city3',state:'state3'},
	      {Id:104,firstName:'Student4', lastName:'Student4 lastName',dob:'1/01/2001',city:'city4',state:'state4'},
	      {Id:105,firstName:'Student5', lastName:'Student5 lastName',dob:'1/01/2001',city:'city5',state:'state5'},
	      {Id:106,firstName:'Student6', lastName:'Student6 lastName',dob:'1/01/2001',city:'city6',state:'state6'}
	      ]
});