Ext.define('myapp.view.StudentPage',{
	extend:'Ext.grid.Panel',
	alias:'widget.studentPage',
	name:'studentPage',
	title:'Student details',
	
	initComponent:function(){
		this.store='StudentStore',
		this.plugins=[Ext.create('Ext.grid.plugin.CellEditing',{
			clicksToEdit:2
		})],
		this.columns=[
		     {header:'Id', dataIndex:'Id'},
		     {header:'First Name',dataIndex:'firstName',flex:1},
		     {header:'Last Name',dataIndex:'lastName',flex:1},
		     {header:'Date of Birth',dataIndex:'dob',flex:1},
		     {header:'City',dataIndex:'city',flex:1},
		     {header:'State',dataIndex:'state',flex:1},
		     {header:'File',dataIndex:'file',flex:1,renderer:this.formatUrl}
		     ],
		     
	    this.buttons=[{text:'Back',action:'back'}],
		this.callParent(arguments);
	},

formatUrl:function(value){
	myUrl='';
	if(value!=''){
		myUrl='<a href="http://' + value + '" target="_blank">' + value +'</a>';
	}
	return myUrl;
}
});