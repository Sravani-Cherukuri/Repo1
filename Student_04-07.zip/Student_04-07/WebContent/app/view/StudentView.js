Ext.define('myapp.view.StudentView',{
	extend:'Ext.grid.Panel',
	alias:'widget.studentGrid',
	//name:'studentGrid',
	id:'studentGrid',
	model:'StudentModel',
	store:'DataStore',
	title:'Student Page',
	autoScroll:true,
	selType:'checkboxmodel',
	selModel:{mode:'MULTI'},
	initComponent:function(){
		this.store='DataStore',
		this.plugins=[Ext.create('Ext.grid.plugin.CellEditing',{
			clicksToEdit:2
		})],
		this.columns=[
		       {
				    text:'Id',
				    dataIndex:'Id',
				    width:35,
				    editor:{
				    	allowBlank:false
				    }
			   },
		       {
		    	   text:'First name',
		    	   dataIndex:'firstName',
		    	   flex:1,
		    	   editor:{
		    		   allowBlank:false
		    	   }
		       },
		       {
		    	   text:'Last name',
		    	   dataIndex:'lastName',
		    	   flex:1,
		    	   editor:{
		    		   allowBlank:false
		    	   }
		       },
		       {
		    	   text:'Date of Birth ',
		    	   dataIndex:'dob',
		    	   flex:1,
		    	   editor:{
		    		   xtype:'datefield',
		    		   format:'d-m-Y'
		    	   }
		       },
		       {
		    	   text:'City',
		    	   dataIndex:'city',
		    	   flex:1,
		    	   editor:{
		    		   allowBlank:false
		    	   }
		       },
		       {
		    	   text:'State',
		    	   dataIndex:'state',
		    	   flex:1,
		    	   editor:{
		    		  /*xtype:'combobox',
		    		  store:'states',
		    		  displayField:'state',
		    		  valueField:'state',
		    		  queryMode:'local',
		    		  editable:false*/
		    		  allowBlank:false
		    	   },
		       },
		       {
			       text: 'File', 
	               dataIndex: 'file', 
	               width: 200,
	               editor:{
	                   xtype: 'filefield',
	                   emptyText: 'Select your File',
	                   name: 'file',
	                   buttonText: 'Browse',
	               	},
               	listeners: {
                    change: function(fld,value) {
                    	console.log(fld);
                        console.log(value);
                        var newValue = value.replace(/C:\\fakepath\\/g, '');
                       // var newValue = value.replace(/^c:\\fakepath\\/i, '');
                        console.log(newValue);
                        fld.setRawValue(newValue);
                       /* var grid = this.up('grid');
                        var store = grid.getStore();
                        var newStore = Ext.create('myapp.store.StudentStore',{});
                        store.insert(store.data.columns.length, newStore);*/
                        
                    }
                }
		       }
		              ],
		      this.dockedItems=[{
		    	  xtype:'toolbar',
		    	  dock:'bottom',
		    	  ui:'footer',
		    	  layout:{pack:'center'},
		    	  items:[
		    	       {text:'Add',action:'add'},
		    	       {text:'Save',action:'save'},
		    	       {text:'Load',action:'load'},
		    	       {text:'Delete',action:'delete'},
		    	       {text:'Logout',action:'logout'}
		    	         ]
		      }],
		     
		this.callParent(arguments);
	}
});