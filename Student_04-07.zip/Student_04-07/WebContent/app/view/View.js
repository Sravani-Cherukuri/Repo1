Ext.define('myapp.view.View',{
	extend:'Ext.form.Panel',
	alias:'widget.loginForm',
	stores:['LoginStore'],
	name:'loginForm',
	id:'login',
	title:'Login Form',	    
	initComponent:function(){
		this.items=[
		  {
			  style: 'margin:0 auto;margin-top:100px;',
		items:[{
			xtype:'textfield',
			fieldLabel:'Username',
			width:350,
			id:'username',
			name:'username',
			allowBlank:false,
			minLength:3,
			maxLength:30,
			 style: 'margin:0 auto;margin-top:20px;'},
			{
			xtype:'textfield',
			fieldLabel:'Password',
			width:350,
			id:'password',
			name:'password',
			inputType:'password',
			allowBlank:false,
			minLength:8,
			maxLength:16,
			style: 'margin:0 auto;margin-top:20px;'
		},{
			xtype:'button',
			text:'Login',
			action:'login',
			style:'margin-left:600px'
		
		},{
			xtype:'button',
			text:'Cancel',
			action:'cancel',
			scope:this,
			handler:this.close
		},
		{
			xtype:'button',
			text:'Forgot password',
			action:'forgot',
		}],
	}]
		this.callParent(arguments);
	}
});